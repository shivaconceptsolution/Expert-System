/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Hp
 */
@WebServlet(urlPatterns = {"/QuestionSer"})
public class QuestionSer extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       PrintWriter out = response.getWriter();
        try
        {
          Class.forName("com.mysql.jdbc.Driver");
         Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/expertsystem","root","");
          Statement st = conn.createStatement();
          int x = st.executeUpdate("insert into questions(title,customerid,catid) values('"+request.getParameter("txttitle")+"','"+request.getParameter("txtcustid")+"','"+request.getParameter("txtcatid")+"')");
          
          if(x!=0)
          {
             response.sendRedirect("addquestion.jsp?q=data inserted successfully");
          }
          else
          {
               response.sendRedirect("addquestion.jsp?q=data not inserted successfully");
          }
        }
        catch(Exception ex)
        {
          out.print(ex.getMessage().toString());  
        }
    }

}
